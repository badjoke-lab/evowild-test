S型の立体造形スタディ — REVISE

このフォルダーで python3 -m http.server 8000 --bind 0.0.0.0 を実行。
http://localhost:8000/ をブラウザで開く。
source/s-form.blend は編集可能な原本。コードから再制作する場合は指定ブランチのリポジトリを利用する。
物理GPU・Android実機は未検証。mainと旧資産は変更していない。
