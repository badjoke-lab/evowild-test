EvoWild Run — Sprite Stacking 実証デモ

ZIPを展開し index.html をChrome/Edge等のブラウザで開く構成です。
検証環境ではfile://直開きが管理ポリシーで拒否されたため、file originでの動作は未検証です。
直接開けない場合は python3 start-demo.py を実行して表示されるlocalhost URLを開いてください。
ローカルHTTPからHTMLを読んだ後、通信を遮断して全描画方式・全層/ポーズ条件を検証しています。
全素材を埋め込み、通常版の全層/全ポーズ・2D/GLB/Canvas/WebGL切替を含みます。
検証結果は evidence/report.html 。5動画、5方向比較、性能CSV/JSONを同梱。
←→/AD: 連続旋回、↑↓/WS: 加減速、SPACE: 一時停止。タッチ操作もあります。
連続IK基準は元制御1×を評価する比較専用です。

判定: REVISE。元のSモデル・既存四足走行を使用。新規クリーチャー生成なし。
単一HTMLには全素材を埋め込むため、ロードとメモリは通常版の計測とは異なります。
このZIPを性能計測の通常版データに混ぜないでください。

再現スクリプトと全ソース:
https://github.com/badjoke-lab/evowild-test/tree/exp/2p5d-sprite-stacking-20261118
