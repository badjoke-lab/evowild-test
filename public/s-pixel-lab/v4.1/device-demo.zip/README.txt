EvoWild Run / S型 v4.1
1. ZIPを展開し、index.htmlをWebGL 2対応ブラウザで開いてください。
2. PCとAndroidを同じWi-Fiで比較する場合は、展開フォルダーで python3 -m http.server 8000 --bind 0.0.0.0 を起動します。
   PCは http://localhost:8000/index.html 、AndroidのChromeは http://PCのLANアドレス:8000/index.html を開きます。
3. 同じ描画サイズを選び、端末名を入力して「2条件を測定」。タブを前面に保ち、完了後「JSONを保存」。
4. v4へのリンクで同じ操作を繰り返します。どちらの版も画面内でGPU名と結果を確認できます。
詳細とSwiftShader結果は evidence/review.html にあります。
