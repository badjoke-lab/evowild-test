EvoWild Run / Ridge Oval — S型v4.1 仮統合
ZIPを展開し、このREADMEと同じフォルダーで次を実行してください。
python3 -m http.server 8000 --bind 0.0.0.0
PC: http://localhost:8000/
Android: PCと同じWi-Fiに接続し、Chromeで http://PCのLANアドレス:8000/ を開く。
初期編成は通常の18体です。「出走設定」で頭数・編成を選んだら「新しいレース」。
「S型表示」は走行中に変更できます。実機計測と比較の手順は
evowild-test/race-integration/README.md にあります。
統合レースの改修前後の比較・負荷表・動画は http://localhost:8000/evowild-test/ridge-performance/ にあります。
