EvoWild Run
ZIPを展開し、このフォルダーで python3 start.py を実行します。
Windows の Python Launcher では py start.py を実行します。
ブラウザーが開かない場合は http://127.0.0.1:8000/game-2p5d.html を開いてください。
コースと出走個体を選び、Agent設定から観戦を開始します。
画面右上の観戦カメラで8方向と横追従に切り替えられます。
結果は同じブラウザーの同じアドレスに保存されます。終了は Ctrl+C です。
